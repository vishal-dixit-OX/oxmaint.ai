import React, { useState, useEffect, useRef } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faGlobe,
  faCircle,
  faExclamationTriangle,
  faMicrochip,
  faChartLine,
  faTools,
  faCog,
  faPaperPlane,
  faRobot,
  faVideo,
  faCheckCircle,
  faTimesCircle,
  faArrowUp,
  faArrowDown,
  faClock,
  faCheck,
  faTimes,
  faChartPie,
  faThermometerHalf,
  faTachometerAlt,
  faWater,
  faFilter,
  faIndustry,
  faPercent,
  faDollarSign,
  faUserClock,
  faShippingFast,
  faExchangeAlt,
  faExclamationCircle,
  faTasks,
  faHandsHelping,
  faSearch,
  faBolt
} from "@fortawesome/free-solid-svg-icons";
import { Chart, registerables } from "chart.js";
import { Factory } from "lucide-react";

// Register Chart.js components
Chart.register(...registerables);

/**
 * Main OEE Dashboard Component
 */
const FactoryKPI = () => {
  const [language, setLanguage] = useState("en");
  const [selectedMachine, setSelectedMachine] = useState("all");

  // Mock data for OEE metrics
  const [oeeData, setOeeData] = useState({
    availability: 88,
    performance: 85,
    quality: 95,
    fpy: 98,
    throughput: 210,
    oeeScore: 77.6,
  });

  // Mock data for sensor readings
  const [sensorData, setSensorData] = useState({
    all: { temperature: 25, pressure: 15, humidity: 60 },
    machine1: { temperature: 22, pressure: 12, humidity: 55 },
    machine2: { temperature: 28, pressure: 18, humidity: 65 },
    machine3: { temperature: 24, pressure: 14, humidity: 58 },
  });

 const [lastUpdated, setLastUpdated] = useState(new Date().toLocaleString());
  
useEffect(() => {
  const timer = setInterval(() => {
    setLastUpdated(new Date().toLocaleString(language === 'en' ? 'en-US' : 'ar-SA'));
  }, 1000);
  
  return () => clearInterval(timer);
}, [language]);

  // Simulate real-time sensor data updates
  useEffect(() => {
    const interval = setInterval(() => {
      setSensorData((prevData) => {
        const newData = { ...prevData };

        Object.keys(newData).forEach((machine) => {
          newData[machine] = {
            temperature: Math.max(
              20,
              Math.min(
                30,
                newData[machine].temperature + (Math.random() - 0.5) * 0.5
              )
            ),
            pressure: Math.max(
              10,
              Math.min(
                20,
                newData[machine].pressure + (Math.random() - 0.5) * 0.2
              )
            ),
            humidity: Math.max(
              50,
              Math.min(
                70,
                newData[machine].humidity + (Math.random() - 0.5) * 0.5
              )
            ),
          };
        });

        return newData;
      });
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  // CSS for RTL/LTR language support
  const containerClass =
    language === "ar" ? "font-cairo rtl" : "font-roboto ltr";

  return (
    <div className={`min-h-screen bg-gray-50 ${containerClass}`}>
      <Header language={language} setLanguage={setLanguage} />

      <div className="container mx-auto p-4">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Chatbot and Camera Grid */}
          <div className="lg:col-span-3 space-y-6">
            <Chatbot language={language} />
            <CameraGrid language={language} />
          </div>

          {/* Middle Column: Main OEE Metrics */}
          <div className="lg:col-span-6 space-y-6">
            <OEEMetrics language={language} oeeData={oeeData} />
          </div>

          {/* Right Column: Additional KPIs */}
          <div className="lg:col-span-3 space-y-6">
            <SidebarKPIs language={language} />
          </div>
        </div>

        {/* Full Width Sections */}
        <div className="mt-6 space-y-6">
          <SensorMonitoring
            language={language}
            sensorData={sensorData[selectedMachine]}
            selectedMachine={selectedMachine}
            setSelectedMachine={setSelectedMachine}
          />

          <AdditionalKPIs language={language} />
        </div>
      </div>
    </div>
  );
};

/**
 * Header Component with Language Toggle
 */
const Header = ({ language, setLanguage, lastUpdated }) => {
  const translations = {
    en: {
      title: "OXmaint.ai OEE Dashboard - AI-Powered Factory Monitoring",
      live: "LIVE",
      back: "Back to Dashboard",
      lastUpdated: "Last Updated",
      language: "Language",
      english: "English",
      arabic: "العربية",
    },
    ar: {
      title: "لوحة تحكم OEE من OXmaint.ai - مراقبة المصنع بمساعدة الذكاء الاصطناعي",
      live: "مباشر",
      back: "العودة إلى لوحة المعلومات",
      lastUpdated: "آخر تحديث",
      language: "اللغة",
      english: "الإنجليزية",
      arabic: "العربية",
    },
  };

  const toggleLanguage = (lang) => {
    setLanguage(lang);
  };

  return (
    <div className="bg-indigo-900 text-white shadow-md">
      <div className="container mx-auto px-4 py-3">
        {/* Back button and header content */}
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <button
              className="mr-4 text-sm font-medium py-1 px-3 bg-indigo-700 text-white rounded-lg hover:bg-indigo-600 focus:outline-none transition-colors duration-200 ease-in-out flex items-center gap-1"
              onClick={() => window.location.href = '/oee-dashboard'}
            >
              <span>←</span>
              <span>{translations[language].back}</span>
            </button>
            
            <h1 className="text-xl md:text-2xl font-bold">
              {translations[language].title}
            </h1>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Last updated info */}
            <div className="text-white text-sm">
              {translations[language].lastUpdated}: {lastUpdated}
            </div>
            
            {/* Language dropdown */}
            <div className="relative group">
              <button className="flex items-center hover:bg-indigo-800 px-3 py-1 rounded transition-colors">
                <FontAwesomeIcon icon={faGlobe} className="mr-2" />
                <span>{language === "en" ? "English" : "العربية"}</span>
                <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                </svg>
              </button>
              
              <div className="absolute right-0 mt-1 w-48 bg-white rounded-md shadow-lg py-1 z-10 hidden group-hover:block">
                <button 
                  onClick={() => toggleLanguage("en")} 
                  className={`block px-4 py-2 text-sm text-gray-700 hover:bg-indigo-100 w-full text-left ${language === "en" ? "bg-indigo-100" : ""}`}
                >
                  English
                </button>
                <button 
                  onClick={() => toggleLanguage("ar")} 
                  className={`block px-4 py-2 text-sm text-gray-700 hover:bg-indigo-100 w-full text-left ${language === "ar" ? "bg-indigo-100" : ""}`}
                >
                  العربية
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

/**
 * Chatbot Component
 */
const Chatbot = ({ language }) => {
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef(null);
  
  const translations = {
    en: {
      title: "OXmaint.ai Assistant",
      placeholder: "Ask a question...",
      send: "Send",
      initialMessage: "Hello! I'm your factory assistant. How can I help you today?"
    },
    ar: {
      title: "مساعد OXmaint.ai",
      placeholder: "اطرح سؤالاً...",
      send: "إرسال",
      initialMessage: "مرحبا! أنا مساعدك في المصنع. كيف يمكنني مساعدتك اليوم؟"
    }
  };

  // Add initial bot message when component mounts only once
  useEffect(() => {
    if (messages.length === 0) {
      setMessages([
        { type: 'bot', text: translations[language].initialMessage }
      ]);
    }
  }, []); // Remove language dependency to prevent re-rendering


  // Auto-scroll to the most recent message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = () => {
    if (!inputText.trim()) return;
    
    // Add user message
    setMessages(prev => [...prev, { type: 'user', text: inputText }]);
    
    // Clear input immediately for better UX
    const userInput = inputText;
    setInputText('');
    
    // Simulate bot response based on input
    setTimeout(() => {
      let response = translations[language].initialMessage;
      
      if (userInput.toLowerCase().includes('oee')) {
        response = language === 'en' 
          ? 'Current OEE is 77.6%. Would you like detailed insights?' 
          : 'OEE الحالي هو 77.6٪. هل تريد رؤية تفاصيل أكثر؟';
      } else if (userInput.toLowerCase().includes('sensor')) {
        response = language === 'en'
          ? 'Check the real-time sensor data below for temperature, pressure, and humidity.'
          : 'تحقق من بيانات الاستشعار في الوقت الفعلي أدناه لدرجة الحرارة والضغط والرطوبة.';
      } else if (userInput.toLowerCase().includes('machine')) {
        response = language === 'en'
          ? 'Select a machine from the sensor filter to view specific data.'
          : 'حدد آلة من مرشح المستشعر لعرض البيانات المحددة.';
      } else if (userInput.toLowerCase().includes('kpi')) {
        response = language === 'en'
          ? 'View the additional KPIs below for metrics like capacity utilization, downtime, and more.'
          : 'اطلع على مؤشرات الأداء الرئيسية الإضافية أدناه للحصول على مقاييس مثل استخدام القدرة ووقت التوقف والمزيد.';
      }
      
      setMessages(prev => [...prev, { type: 'bot', text: response }]);
    }, 1000);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-md border border-indigo-100 flex flex-col h-[600px]">
      <div className="bg-indigo-900 text-white py-3 px-4 rounded-t-xl flex items-center">
        <FontAwesomeIcon icon={faRobot} className="mr-2" />
        <h2 className="font-bold">{translations[language].title}</h2>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 bg-gray-50">
        {messages.map((msg, index) => (
          <div 
            key={index} 
            className={`mb-3 max-w-[80%] p-3 rounded-lg ${
              msg.type === 'user' 
                ? 'ml-auto bg-indigo-600 text-white rounded-br-none' 
                : 'mr-auto bg-gray-200 text-gray-800 rounded-bl-none'
            }`}
          >
            {msg.text}
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>
      
      <div className="border-t border-gray-200 p-3 flex">
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder={translations[language].placeholder}
          className="flex-1 border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
        />
        <button
          onClick={handleSendMessage}
          className="ml-2 bg-indigo-600 text-white rounded-lg px-4 py-2 hover:bg-indigo-700 transition-colors whitespace-nowrap"
        >
          <FontAwesomeIcon icon={faPaperPlane} />
          <span className="ml-2 md:inline hidden">{translations[language].send}</span>
        </button>
      </div>
    </div>
  );
};

/**
 * Camera Grid Component
 */
const CameraGrid = ({ language }) => {
  const translations = {
    en: {
      videoFeed: "Video Feed Preview (Cycling)",
      viewAll: "View All Cameras",
    },
    ar: {
      videoFeed: "معاينة تغذية الفيديو (دورية)",
      viewAll: "عرض جميع الكاميرات",
    },
  };

  // Mock camera data
  const cameras = [
    { id: "C1", status: "active", value: 82 },
    { id: "C2", status: "active", value: 90 },
    { id: "C3", status: "warning", value: 75 },
    { id: "C4", status: "active", value: 88 },
    { id: "C5", status: "down", value: 60 },
    { id: "C6", status: "active", value: 85 },
    { id: "C7", status: "active", value: 87 },
    { id: "C8", status: "active", value: 92 },
    { id: "C9", status: "active", value: 89 },
    { id: "C10", status: "active", value: 91 },
  ];

  const getStatusIcon = (status) => {
    switch (status) {
      case "active":
        return (
          <FontAwesomeIcon icon={faCheckCircle} className="text-green-500" />
        );
      case "warning":
        return (
          <FontAwesomeIcon
            icon={faExclamationTriangle}
            className="text-yellow-500"
          />
        );
      case "down":
        return (
          <FontAwesomeIcon icon={faTimesCircle} className="text-red-500" />
        );
      default:
        return null;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "active":
        return "border-green-500";
      case "warning":
        return "border-yellow-500";
      case "down":
        return "border-red-500";
      default:
        return "border-gray-300";
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-5 gap-2">
        {cameras.map((camera) => (
          <div
            key={camera.id}
            className={`bg-white rounded-lg p-2 text-center text-xs font-medium border-2 ${getStatusColor(
              camera.status
            )} transition-all hover:shadow-md`}
          >
            <div className="flex justify-center items-center mb-1">
              {getStatusIcon(camera.status)}
            </div>
            <div>
              {camera.id}: {camera.value}%
            </div>
          </div>
        ))}
      </div>

      <div className="bg-indigo-900 text-white rounded-lg p-3 flex flex-col items-center">
        <FontAwesomeIcon icon={faVideo} className="mb-2 text-lg" />
        <div className="text-center text-sm">
          {translations[language].videoFeed}
        </div>
        <button className="mt-2 bg-indigo-700 hover:bg-indigo-800 text-white text-xs py-1 px-3 rounded-full transition-colors">
          {translations[language].viewAll}
        </button>
      </div>
    </div>
  );
};

/**
 * OEE Metrics Component with Charts
 */
/**
 * OEE Metrics Component with Charts
 */
const OEEMetrics = ({ language, oeeData }) => {
  const availabilityChartRef = useRef(null);
  const performanceChartRef = useRef(null);
  const qualityChartRef = useRef(null);
  const fpyChartRef = useRef(null);
  const throughputChartRef = useRef(null);
  const chartsInitialized = useRef(false);

  const translations = {
    en: {
      availability: "Availability",
      uptime: "Uptime",
      downtime: "Downtime",
      performance: "Performance Efficiency",
      output: "Output",
      units: "units",
      quality: "Quality Level",
      goodUnits: "Good Units",
      defects: "Defects",
      fpy: "First Pass Yield (FPY)",
      throughput: "Throughput",
      overLast: "Over last 24h",
      overallOEE: "Overall OEE",
      trend: "Trend:",
      stableOver: "Stable over 7 days",
    },
    ar: {
      availability: "التوافر",
      uptime: "وقت التشغيل",
      downtime: "وقت التوقف",
      performance: "كفاءة الأداء",
      output: "الإنتاج",
      units: "وحدة",
      quality: "مستوى الجودة",
      goodUnits: "الوحدات الجيدة",
      defects: "العيوب",
      fpy: "الإنتاجية في المرة الأولى",
      throughput: "الإنتاجية",
      overLast: "خلال آخر 24 ساعة",
      overallOEE: "الكفاءة الكلية للمعدات",
      trend: "الاتجاه:",
      stableOver: "مستقر على مدى 7 أيام",
    },
  };

  // Function to destroy all charts
  const destroyCharts = () => {
    if (availabilityChartRef.current) {
      availabilityChartRef.current.destroy();
      availabilityChartRef.current = null;
    }
    if (performanceChartRef.current) {
      performanceChartRef.current.destroy();
      performanceChartRef.current = null;
    }
    if (qualityChartRef.current) {
      qualityChartRef.current.destroy();
      qualityChartRef.current = null;
    }
    if (fpyChartRef.current) {
      fpyChartRef.current.destroy();
      fpyChartRef.current = null;
    }
    if (throughputChartRef.current) {
      throughputChartRef.current.destroy();
      throughputChartRef.current = null;
    }
  };

  // Create charts only once when component mounts
  useEffect(() => {
    // Initialize all charts on first render or language change
    if (!chartsInitialized.current || language) {
      // Clean up existing charts first
      destroyCharts();
      
      // Create Availability Gauge Chart
      const availabilityCtx = document.getElementById("availabilityGauge");
      if (availabilityCtx) {
        availabilityChartRef.current = new Chart(availabilityCtx, {
          type: "doughnut",
          data: {
            datasets: [
              {
                data: [oeeData.availability, 100 - oeeData.availability],
                backgroundColor: ["#10B981", "#EF4444"],
                borderWidth: 0,
                cutout: "70%",
              },
            ],
          },
          options: {
            responsive: true,
            circumference: 180,
            rotation: -90,
            plugins: {
              legend: { display: false },
              tooltip: { enabled: false },
            },
          },
        });
      }

      // Create Performance Bar Chart
      const performanceCtx = document.getElementById("performanceBar");
      if (performanceCtx) {
        performanceChartRef.current = new Chart(performanceCtx, {
          type: "bar",
          data: {
            labels: ["Actual", "Ideal"],
            datasets: [
              {
                data: [5000, 5500],
                backgroundColor: ["#4F46E5", "#9CA3AF"],
                borderWidth: 0,
                borderRadius: 4,
              },
            ],
          },
          options: {
            responsive: true,
            scales: {
              y: {
                beginAtZero: true,
                grid: { display: false },
              },
              x: {
                grid: { display: false },
              },
            },
            plugins: {
              legend: { display: false },
            },
          },
        });
      }

      // Create Quality Pie Chart
      const qualityCtx = document.getElementById("qualityPie");
      if (qualityCtx) {
        qualityChartRef.current = new Chart(qualityCtx, {
          type: "pie",
          data: {
            labels: [
              translations[language].goodUnits,
              translations[language].defects,
            ],
            datasets: [
              {
                data: [4900, 100],
                backgroundColor: ["#10B981", "#EF4444"],
                borderWidth: 0,
              },
            ],
          },
          options: {
            responsive: true,
            plugins: {
              legend: {
                position: "bottom",
                labels: {
                  font: { size: 10 },
                },
              },
            },
          },
        });
      }

      // Create FPY Gauge Chart
      const fpyCtx = document.getElementById("fpyGauge");
      if (fpyCtx) {
        fpyChartRef.current = new Chart(fpyCtx, {
          type: "doughnut",
          data: {
            datasets: [
              {
                data: [oeeData.fpy, 100 - oeeData.fpy],
                backgroundColor: ["#10B981", "#EF4444"],
                borderWidth: 0,
                cutout: "70%",
              },
            ],
          },
          options: {
            responsive: true,
            circumference: 180,
            rotation: -90,
            plugins: {
              legend: { display: false },
              tooltip: { enabled: false },
            },
          },
        });
      }

      // Create Throughput Line Chart
      const throughputCtx = document.getElementById("throughputLine");
      if (throughputCtx) {
        throughputChartRef.current = new Chart(throughputCtx, {
          type: "line",
          data: {
            labels: ["00:00", "06:00", "12:00", "18:00", "24:00"],
            datasets: [
              {
                label: "Throughput",
                data: [200, 210, 215, 205, 210],
                borderColor: "#4F46E5",
                backgroundColor: "rgba(79, 70, 229, 0.1)",
                fill: true,
                tension: 0.4,
                pointRadius: 2,
                pointHoverRadius: 4,
              },
            ],
          },
          options: {
            responsive: true,
            scales: {
              y: {
                beginAtZero: true,
                grid: {
                  display: true,
                  color: "rgba(0, 0, 0, 0.05)",
                },
              },
              x: {
                grid: { display: false },
              },
            },
            plugins: {
              legend: { display: false },
            },
          },
        });
      }
      
      chartsInitialized.current = true;
    }
    
    // Cleanup function to destroy charts when component unmounts
    return () => {
      destroyCharts();
    };
  }, [language]); // Only re-create charts when language changes

  // Update chart data when oeeData changes without recreating the charts
  useEffect(() => {
    if (!chartsInitialized.current) return;
    
    // Update Availability Gauge Chart data
    if (availabilityChartRef.current) {
      availabilityChartRef.current.data.datasets[0].data = [
        oeeData.availability, 
        100 - oeeData.availability
      ];
      availabilityChartRef.current.update('none');
    }
    
    // Update FPY Gauge Chart data
    if (fpyChartRef.current) {
      fpyChartRef.current.data.datasets[0].data = [
        oeeData.fpy, 
        100 - oeeData.fpy
      ];
      fpyChartRef.current.update('none');
    }
    
    // You can update other charts data here as needed
    
  }, [oeeData]);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Availability */}
        <div className="bg-white rounded-xl shadow-sm p-4 border border-indigo-100">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-indigo-900 font-bold flex items-center">
              <FontAwesomeIcon icon={faClock} className="mr-2" />
              {translations[language].availability}
            </h3>
            <span className="text-2xl font-bold text-indigo-900">
              {oeeData.availability}%
            </span>
          </div>
          <div className="h-32 flex justify-center items-center">
            <canvas id="availabilityGauge"></canvas>
          </div>
          <div className="flex justify-between text-sm mt-2 text-gray-600">
            <span>
              <FontAwesomeIcon
                icon={faArrowUp}
                className="text-green-500 mr-1"
              />
              {translations[language].uptime}: 23h 45m
            </span>
            <span>
              <FontAwesomeIcon
                icon={faArrowDown}
                className="text-red-500 mr-1"
              />
              {translations[language].downtime}: 15m
            </span>
          </div>
        </div>

        {/* Performance */}
        <div className="bg-white rounded-xl shadow-sm p-4 border border-indigo-100 h-full">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-indigo-900 font-bold flex items-center">
              <FontAwesomeIcon icon={faChartPie} className="mr-2" />
              {translations[language].performance}
            </h3>
            <span className="text-2xl font-bold text-indigo-900">{oeeData.performance}%</span>
          </div>
          <div className="h-32 w-full flex justify-center items-center">
            <canvas id="performanceBar" height="130"></canvas>
          </div>
          <div className="text-sm mt-2 text-gray-600 text-center">
            {translations[language].output}: 5,000 / 5,500 {translations[language].units}
          </div>
        </div>

        {/* Quality */}
        <div className="bg-white rounded-xl shadow-sm p-4 border border-indigo-100">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-indigo-900 font-bold flex items-center">
              <FontAwesomeIcon icon={faCheck} className="mr-2" />
              {translations[language].quality}
            </h3>
            <span className="text-2xl font-bold text-indigo-900">
              {oeeData.quality}%
            </span>
          </div>
          <div className="h-32 flex justify-center items-center">
            <canvas id="qualityPie"></canvas>
          </div>
          <div className="flex justify-between text-sm mt-2 text-gray-600">
            <span>{translations[language].goodUnits}: 4,900</span>
            <span>{translations[language].defects}: 100</span>
          </div>
        </div>

        {/* FPY */}
        <div className="bg-white rounded-xl shadow-sm p-4 border border-indigo-100">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-indigo-900 font-bold flex items-center">
              <FontAwesomeIcon icon={faCheck} className="mr-2" />
              {translations[language].fpy}
            </h3>
            <span className="text-2xl font-bold text-indigo-900">
              {oeeData.fpy}%
            </span>
          </div>
          <div className="h-32 flex justify-center items-center">
            <canvas id="fpyGauge"></canvas>
          </div>
        </div>

        {/* Throughput */}
        <div className="bg-white rounded-xl shadow-sm p-4 border border-indigo-100 h-full">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-indigo-900 font-bold flex items-center">
              <FontAwesomeIcon icon={faChartPie} className="mr-2" />
              {translations[language].throughput}
            </h3>
            <span className="text-2xl font-bold text-indigo-900">{oeeData.throughput} {translations[language].units}/hr</span>
          </div>
          <div className="h-32 w-full">
            <canvas id="throughputLine" height="130"></canvas>
          </div>
          <div className="text-sm mt-2 text-gray-600 text-center">
            {translations[language].overLast}
          </div>
        </div>

        {/* Overall OEE Score */}
        <div className="bg-indigo-900 text-white rounded-xl shadow-md p-6 text-center">
          <h3 className="text-xl font-bold mb-2">
            {translations[language].overallOEE}
          </h3>
          <div className="text-5xl font-bold mb-2">{oeeData.oeeScore}%</div>
          <div className="text-sm opacity-80">
            {translations[language].trend} {translations[language].stableOver}
          </div>
        </div>
      </div>
    </div>
  );
};
/**
 * Sidebar KPIs Component
 */
const SidebarKPIs = ({ language }) => {
  const translations = {
    en: {
      teep: "TEEP",
      mtbf: "MTBF",
      mttr: "MTTR",
      mttd: "MTTD",
      mtbm: "MTBM",
      oeeLoss: "OEE Loss",
      cycleTime: "Cycle Time Efficiency",
      energyEfficiency: "Energy Efficiency",
      aiAlert: "AI Alert",
      maintenance: "Maintenance in",
    },
    ar: {
      teep: "أداء المعدات الفعال الكلي",
      mtbf: "متوسط الوقت بين الأعطال",
      mttr: "متوسط وقت الإصلاح",
      mttd: "متوسط وقت الكشف",
      mtbm: "متوسط الوقت بين الصيانة",
      oeeLoss: "خسارة الكفاءة الكلية",
      cycleTime: "كفاءة وقت الدورة",
      energyEfficiency: "كفاءة الطاقة",
      aiAlert: "تنبيه الذكاء الاصطناعي",
      maintenance: "صيانة خلال",
    },
  };

  // Mock KPI data
  const kpiData = [
    {
      id: "teep",
      name: translations[language].teep,
      value: "70%",
      icon: faPercent,
    },
    {
      id: "mtbf",
      name: translations[language].mtbf,
      value: "48h",
      icon: faClock,
    },
    {
      id: "mttr",
      name: translations[language].mttr,
      value: "20m",
      icon: faTools,
    },
    {
      id: "mttd",
      name: translations[language].mttd,
      value: "5m",
      icon: faSearch,
    },
    {
      id: "mtbm",
      name: translations[language].mtbm,
      value: "72h",
      icon: faCog,
    },
    {
      id: "oeeLoss",
      name: translations[language].oeeLoss,
      value: "22.4%",
      icon: faPercent,
    },
    {
      id: "cycleTime",
      name: translations[language].cycleTime,
      value: "92%",
      icon: faClock,
    },
    {
      id: "energyEfficiency",
      name: translations[language].energyEfficiency,
      value: "85%",
      icon: faBolt,
    },
  ];

  return (
    <div className="space-y-3">
      {kpiData.map((kpi) => (
        <div
          key={kpi.id}
          className="bg-white rounded-lg shadow-sm p-3 border border-indigo-100 hover:shadow-md transition-shadow"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center text-indigo-900">
              <FontAwesomeIcon
                icon={kpi.icon}
                className="mr-2 text-indigo-500"
              />
              <h4 className="font-medium text-sm">{kpi.name}</h4>
            </div>
            <div className="font-bold text-lg">{kpi.value}</div>
          </div>
        </div>
      ))}

      {/* AI Alert Card */}
      <div className="bg-red-50 border-l-4 border-red-500 rounded-lg shadow-sm p-3 animate-pulse">
        <div className="flex items-center text-red-800 mb-1">
          <FontAwesomeIcon icon={faExclamationTriangle} className="mr-2" />
          <h4 className="font-bold">{translations[language].aiAlert}</h4>
        </div>
        <div className="text-red-600 ml-6">
          C15: {translations[language].maintenance} 2h
        </div>
      </div>
    </div>
  );
};

/**
 * Sensor Monitoring Component
 */
const SensorMonitoring = ({
  language,
  sensorData,
  selectedMachine,
  setSelectedMachine,
}) => {
  const temperatureChartRef = useRef(null);
  const pressureChartRef = useRef(null);
  const humidityChartRef = useRef(null);

  const translations = {
    en: {
      title: "Real-Time Sensor Monitoring",
      allMachines: "All Machines",
      machine: "Machine",
      temperature: "Temperature",
      pressure: "Pressure",
      humidity: "Humidity",
    },
    ar: {
      title: "مراقبة الحساسات في الوقت الحقيقي",
      allMachines: "جميع الآلات",
      machine: "آلة",
      temperature: "درجة الحرارة",
      pressure: "الضغط",
      humidity: "الرطوبة",
    },
  };

  const generateChartData = (baseValue) => {
    return Array(10)
      .fill()
      .map(() => {
        return baseValue + (Math.random() - 0.5) * 2;
      });
  };

  useEffect(() => {
    // Destroy existing charts to prevent memory leaks
    const charts = [
      temperatureChartRef.current,
      pressureChartRef.current,
      humidityChartRef.current,
    ];

    charts.forEach((chart) => {
      if (chart) chart.destroy();
    });

    const timeLabels = [
      "-9s",
      "-8s",
      "-7s",
      "-6s",
      "-5s",
      "-4s",
      "-3s",
      "-2s",
      "-1s",
      "Now",
    ];

    // Create Temperature Chart
    const temperatureCtx = document.getElementById("temperatureChart");
    if (temperatureCtx) {
      temperatureChartRef.current = new Chart(temperatureCtx, {
        type: "line",
        data: {
          labels: timeLabels,
          datasets: [
            {
              label: `${translations[language].temperature} (°C)`,
              data: generateChartData(sensorData.temperature),
              borderColor: "#4F46E5",
              backgroundColor: "rgba(79, 70, 229, 0.1)",
              fill: true,
              tension: 0.4,
              pointRadius: 2,
              pointHoverRadius: 4,
            },
          ],
        },
        options: {
          responsive: true,
          scales: {
            y: {
              beginAtZero: false,
              min: 20,
              max: 30,
              grid: { color: "rgba(0, 0, 0, 0.05)" },
            },
            x: { grid: { display: false } },
          },
          plugins: {
            legend: { display: false },
          },
        },
      });
    }

    // Create Pressure Chart
    const pressureCtx = document.getElementById("pressureChart");
    if (pressureCtx) {
      pressureChartRef.current = new Chart(pressureCtx, {
        type: "line",
        data: {
          labels: timeLabels,
          datasets: [
            {
              label: `${translations[language].pressure} (PSI)`,
              data: generateChartData(sensorData.pressure),
              borderColor: "#10B981",
              backgroundColor: "rgba(16, 185, 129, 0.1)",
              fill: true,
              tension: 0.4,
              pointRadius: 2,
              pointHoverRadius: 4,
            },
          ],
        },
        options: {
          responsive: true,
          scales: {
            y: {
              beginAtZero: false,
              min: 10,
              max: 20,
              grid: { color: "rgba(0, 0, 0, 0.05)" },
            },
            x: { grid: { display: false } },
          },
          plugins: {
            legend: { display: false },
          },
        },
      });
    }

    // Create Humidity Chart
    const humidityCtx = document.getElementById("humidityChart");
    if (humidityCtx) {
      humidityChartRef.current = new Chart(humidityCtx, {
        type: "line",
        data: {
          labels: timeLabels,
          datasets: [
            {
              label: `${translations[language].humidity} (%)`,
              data: generateChartData(sensorData.humidity),
              borderColor: "#F59E0B",
              backgroundColor: "rgba(245, 158, 11, 0.1)",
              fill: true,
              tension: 0.4,
              pointRadius: 2,
              pointHoverRadius: 4,
            },
          ],
        },
        options: {
          responsive: true,
          scales: {
            y: {
              beginAtZero: false,
              min: 50,
              max: 70,
              grid: { color: "rgba(0, 0, 0, 0.05)" },
            },
            x: { grid: { display: false } },
          },
          plugins: {
            legend: { display: false },
          },
        },
      });
    }
  }, [language, sensorData, translations]);

  const handleMachineChange = (e) => {
    setSelectedMachine(e.target.value);
  };

  return (
    <div className="bg-white rounded-xl shadow-md border border-indigo-100 p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold text-indigo-900 flex items-center">
          <FontAwesomeIcon icon={faMicrochip} className="mr-2" />
          {translations[language].title}
        </h3>

        <div className="flex items-center">
          <FontAwesomeIcon icon={faFilter} className="mr-2 text-gray-500" />
          <select
            value={selectedMachine}
            onChange={handleMachineChange}
            className="border border-gray-300 rounded-lg py-1 px-3 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-gray-700"
          >
            <option value="all">{translations[language].allMachines}</option>
            <option value="machine1">{translations[language].machine} 1</option>
            <option value="machine2">{translations[language].machine} 2</option>
            <option value="machine3">{translations[language].machine} 3</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Temperature Sensor */}
        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <h4 className="font-medium text-indigo-900 flex items-center">
              <FontAwesomeIcon
                icon={faThermometerHalf}
                className="mr-2 text-indigo-500"
              />
              {translations[language].temperature}
            </h4>
            <div className="font-bold text-lg text-indigo-900">
              {sensorData.temperature.toFixed(1)}°C
            </div>
          </div>
          <div className="h-32">
            <canvas id="temperatureChart"></canvas>
          </div>
        </div>

        {/* Pressure Sensor */}
        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <h4 className="font-medium text-indigo-900 flex items-center">
              <FontAwesomeIcon
                icon={faTachometerAlt}
                className="mr-2 text-green-500"
              />
              {translations[language].pressure}
            </h4>
            <div className="font-bold text-lg text-indigo-900">
              {sensorData.pressure.toFixed(1)} PSI
            </div>
          </div>
          <div className="h-32">
            <canvas id="pressureChart"></canvas>
          </div>
        </div>

        {/* Humidity Sensor */}
        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <h4 className="font-medium text-indigo-900 flex items-center">
              <FontAwesomeIcon icon={faWater} className="mr-2 text-amber-500" />
              {translations[language].humidity}
            </h4>
            <div className="font-bold text-lg text-indigo-900">
              {sensorData.humidity.toFixed(1)}%
            </div>
          </div>
          <div className="h-32">
            <canvas id="humidityChart"></canvas>
          </div>
        </div>
      </div>
    </div>
  );
};

/**
 * Additional KPIs Component
 */
const AdditionalKPIs = ({ language }) => {
  const translations = {
    en: {
      title: "Additional Factory KPIs",
      capacity: "Capacity Utilization",
      downtime: "Downtime",
      cycleTime: "Cycle Time",
      throughput: "Throughput",
      deliveryTime: "Delivery Time",
      changeoverTime: "Changeover Time",
      plannedMaintenance: "Planned Maintenance",
      fpy: "First Pass Yield (FPY)",
      leadTime: "Lead Time",
      scrapRate: "Scrap Rate",
      safetyIncident: "Safety Incident Rate",
      maintenanceCosts: "Maintenance Costs",
      defectRate: "Quality Defect Rate",
      productionLeadTime: "Production Lead Time",
      onTimeDelivery: "On-Time Delivery",
      laborEfficiency: "Labor Efficiency",
      utilizationRate: "Utilization Rate",
      reworkRate: "Rework Rate",
      setupTime: "Setup Time",
      yield: "Yield",
      tpmEffectiveness: "TPM Effectiveness",
    },
    ar: {
      title: "مؤشرات الأداء الإضافية للمصنع",
      capacity: "استخدام الطاقة الإنتاجية",
      downtime: "وقت التوقف",
      cycleTime: "وقت الدورة",
      throughput: "الإنتاجية",
      deliveryTime: "وقت التسليم",
      changeoverTime: "وقت التحويل",
      plannedMaintenance: "نسبة الصيانة المخططة",
      fpy: "الإنتاجية في المرة الأولى",
      leadTime: "الوقت الرائد",
      scrapRate: "معدل المخلفات",
      safetyIncident: "معدل الحوادث الأمنية",
      maintenanceCosts: "تكاليف الصيانة",
      defectRate: "معدل عيوب الجودة",
      productionLeadTime: "وقت الإنتاج الرائد",
      onTimeDelivery: "التسليم في الوقت المحدد",
      laborEfficiency: "كفاءة العمالة",
      utilizationRate: "معدل الاستخدام",
      reworkRate: "معدل إعادة العمل",
      setupTime: "وقت الإعداد",
      yield: "العائد",
      tpmEffectiveness: "فعالية الصيانة الإنتاجية الشاملة",
    },
  };

  // KPI Data with icons
  const kpiData = [
    {
      id: "capacity",
      name: translations[language].capacity,
      value: "82%",
      icon: faIndustry,
    },
    {
      id: "downtime",
      name: translations[language].downtime,
      value: "15m",
      icon: faClock,
    },
    {
      id: "cycleTime",
      name: translations[language].cycleTime,
      value: "10s",
      icon: faClock,
    },
    {
      id: "throughput",
      name: translations[language].throughput,
      value: "210 units/hr",
      icon: faChartLine,
    },
    {
      id: "deliveryTime",
      name: translations[language].deliveryTime,
      value: "48h",
      icon: faShippingFast,
    },
    {
      id: "changeoverTime",
      name: translations[language].changeoverTime,
      value: "30m",
      icon: faExchangeAlt,
    },
    {
      id: "plannedMaintenance",
      name: translations[language].plannedMaintenance,
      value: "85%",
      icon: faTools,
    },
    {
      id: "fpy",
      name: translations[language].fpy,
      value: "98%",
      icon: faCheckCircle,
    },
    {
      id: "leadTime",
      name: translations[language].leadTime,
      value: "72h",
      icon: faClock,
    },
    {
      id: "scrapRate",
      name: translations[language].scrapRate,
      value: "2%",
      icon: faExclamationCircle,
    },
    {
      id: "safetyIncident",
      name: translations[language].safetyIncident,
      value: "0.5%",
      icon: faExclamationCircle,
    },
    {
      id: "maintenanceCosts",
      name: translations[language].maintenanceCosts,
      value: "$5,000",
      icon: faDollarSign,
    },
    {
      id: "defectRate",
      name: translations[language].defectRate,
      value: "5%",
      icon: faExclamationCircle,
    },
    {
      id: "productionLeadTime",
      name: translations[language].productionLeadTime,
      value: "24h",
      icon: faClock,
    },
    {
      id: "onTimeDelivery",
      name: translations[language].onTimeDelivery,
      value: "95%",
      icon: faShippingFast,
    },
    {
      id: "laborEfficiency",
      name: translations[language].laborEfficiency,
      value: "90%",
      icon: faUserClock,
    },
    {
      id: "utilizationRate",
      name: translations[language].utilizationRate,
      value: "80%",
      icon: faPercent,
    },
    {
      id: "reworkRate",
      name: translations[language].reworkRate,
      value: "3%",
      icon: faTasks,
    },
    {
      id: "setupTime",
      name: translations[language].setupTime,
      value: "25m",
      icon: faClock,
    },
    {
      id: "yield",
      name: translations[language].yield,
      value: "97%",
      icon: faCheckCircle,
    },
    {
      id: "tpmEffectiveness",
      name: translations[language].tpmEffectiveness,
      value: "88%",
      icon: faHandsHelping,
    },
  ];

  // Group KPIs by color/category for better visual organization
  const getKpiColor = (id) => {
    if (
      [
        "fpy",
        "yield",
        "onTimeDelivery",
        "laborEfficiency",
        "capacity",
      ].includes(id)
    ) {
      return "bg-green-50 border-green-200 text-green-700"; // Good metrics
    } else if (
      [
        "scrapRate",
        "defectRate",
        "reworkRate",
        "safetyIncident",
        "downtime",
      ].includes(id)
    ) {
      return "bg-red-50 border-red-200 text-red-700"; // Metrics where lower is better
    } else if (
      [
        "maintenanceCosts",
        "deliveryTime",
        "leadTime",
        "productionLeadTime",
        "setupTime",
      ].includes(id)
    ) {
      return "bg-amber-50 border-amber-200 text-amber-700"; // Time/cost related
    } else {
      return "bg-indigo-50 border-indigo-200 text-indigo-700"; // Default/other
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-md border border-indigo-100 p-6">
      <h3 className="text-lg font-bold text-indigo-900 mb-6 flex items-center">
        <FontAwesomeIcon icon={faIndustry} className="mr-2" />
        {translations[language].title}
      </h3>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-7 gap-4">
        {kpiData.map((kpi) => (
          <div
            key={kpi.id}
            className={`rounded-lg p-3 border ${getKpiColor(
              kpi.id
            )} flex flex-col items-center justify-center text-center hover:shadow-md transition-shadow`}
          >
            <FontAwesomeIcon icon={kpi.icon} className="mb-2" />
            <h4 className="text-xs font-medium mb-1">{kpi.name}</h4>
            <div className="font-bold text-lg">{kpi.value}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FactoryKPI;
