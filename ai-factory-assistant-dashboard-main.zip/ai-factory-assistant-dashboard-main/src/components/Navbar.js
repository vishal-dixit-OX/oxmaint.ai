import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
<nav className="text-white px-6 py-4 sticky top-0 z-50" style={{ backgroundColor: "#15227a" }}>
  <div className="container mx-auto">
        <div className="flex justify-between items-center">
          <Link to="/" className="text-2xl font-bold flex items-center space-x-2">
            <img src="https://oxmaint.com/assets/img/oxmaint-3.png" role="presentation" aria-hidden="true" alt="" style={{ width: "50px", height: "50px", marginRight: "10px"}} />
            Oxmaint.ai
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            <a href="/benefits" className="hover:text-blue-200">Benefits</a>
            <a href="/features" className="hover:text-blue-200">Features</a>
            <Link to="/community" className="hover:text-blue-200">Community</Link>
            <Link to="/factory_demo" className="bg-blue-700 px-4 py-2 rounded-lg hover:bg-blue-600">Factory Demo</Link>
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden pt-4 pb-2">
            <div className="flex flex-col space-y-4">
              <a href="/benefits" className="hover:text-blue-200" onClick={() => setIsOpen(false)}>Benefits</a>
              <a href="/features" className="hover:text-blue-200" onClick={() => setIsOpen(false)}>Features</a>
              <Link to="/community" className="hover:text-blue-200" onClick={() => setIsOpen(false)}>Community</Link>
              <Link to="/factory_demo" className="bg-blue-700 px-4 py-2 rounded-lg hover:bg-blue-600 inline-block" onClick={() => setIsOpen(false)}>Factory Demo</Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
